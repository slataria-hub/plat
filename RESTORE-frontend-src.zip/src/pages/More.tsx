import { useEffect, useState } from 'react'
import { useAuth } from '../hooks/useAuth'
import { api } from '../api/client'
import type { Property } from '../types'

export default function More() {
  const { user, logout } = useAuth()
  const [properties, setProperties] = useState<Property[]>([])
  const [showForm, setShowForm] = useState(false)
  const [name, setName] = useState('')
  const [address, setAddress] = useState('')
  const [account, setAccount] = useState('')
  const [exporting, setExporting] = useState<number | null>(null)
  const [backingUp, setBackingUp] = useState(false)

  const load = () => api.listProperties().then(setProperties)
  useEffect(() => { load() }, [])

  const create = async (e: React.FormEvent) => {
    e.preventDefault()
    await api.createProperty({ name, address: address || undefined, account_number: account || undefined })
    setShowForm(false)
    setName(''); setAddress(''); setAccount('')
    load()
  }

  const downloadExcel = async (p: Property) => {
    setExporting(p.id)
    try {
      const token = localStorage.getItem('token')
      const res = await fetch(api.exportExcelUrl(p.id), {
        headers: { Authorization: `Bearer ${token}` },
      })
      if (!res.ok) throw new Error('Ошибка экспорта')
      const blob = await res.blob()
      const url = URL.createObjectURL(blob)
      const a = document.createElement('a')
      a.href = url
      a.download = `meterapp_${p.name.replace(/\s+/g, '_')}.xlsx`
      a.click()
      URL.revokeObjectURL(url)
    } catch {
      alert('Не удалось скачать файл')
    } finally {
      setExporting(null)
    }
  }

  const downloadBackup = async () => {
    setBackingUp(true)
    try {
      const token = localStorage.getItem('token')
      const res = await fetch(api.backupZipUrl(), {
        headers: { Authorization: `Bearer ${token}` },
      })
      if (!res.ok) throw new Error('Ошибка')
      const blob = await res.blob()
      const url = URL.createObjectURL(blob)
      const a = document.createElement('a')
      a.href = url
      a.download = `meterapp_backup.zip`
      a.click()
      URL.revokeObjectURL(url)
    } catch {
      alert('Не удалось создать резервную копию')
    } finally {
      setBackingUp(false)
    }
  }

  return (
    <div>
      <h1>Ещё</h1>
      <div className="card user-card">
        <div className="user-name">{user?.name || 'Пользователь'}</div>
        <div className="muted">{user?.email}</div>
        <button className="btn danger mt" onClick={logout}>Выйти</button>
      </div>

      <h2 className="section-title">Объекты</h2>
      {properties.map((p) => (
        <div key={p.id} className="card property-card">
          <div className="property-name">{p.name}</div>
          {p.address && <div className="muted">{p.address}</div>}
          {p.account_number && <div className="muted">Л/С: {p.account_number}</div>}
        </div>
      ))}

      {showForm ? (
        <form className="card form-card" onSubmit={create}>
          <label>Название<input required value={name} onChange={(e) => setName(e.target.value)} placeholder="Квартира на Ленина" /></label>
          <label>Адрес<input value={address} onChange={(e) => setAddress(e.target.value)} /></label>
          <label>Лицевой счёт<input value={account} onChange={(e) => setAccount(e.target.value)} /></label>
          <div className="btn-row">
            <button type="submit" className="btn primary">Сохранить</button>
            <button type="button" className="btn secondary" onClick={() => setShowForm(false)}>Отмена</button>
          </div>
        </form>
      ) : (
        <button className="btn primary" onClick={() => setShowForm(true)}>+ Добавить объект</button>
      )}

      <h2 className="section-title">Экспорт и резервная копия</h2>
      <div className="card">
        <p className="muted" style={{ marginBottom: 12 }}>
          Excel — данные одного объекта. ZIP — полная резервная копия (все объекты, файлы, JSON).
        </p>
        {properties.map((p) => (
          <button
            key={p.id}
            className="btn secondary"
            style={{ marginRight: 8, marginBottom: 8 }}
            disabled={exporting === p.id}
            onClick={() => downloadExcel(p)}
          >
            {exporting === p.id ? 'Формирование…' : `Excel: ${p.name}`}
          </button>
        ))}
        <button
          className="btn primary"
          style={{ marginBottom: 8 }}
          disabled={backingUp || properties.length === 0}
          onClick={downloadBackup}
        >
          {backingUp ? 'Создание ZIP…' : 'Резервная копия (ZIP)'}
        </button>
        {properties.length === 0 && <p className="muted">Сначала добавьте объект</p>}
      </div>
    </div>
  )
}
