import { useEffect, useState } from 'react'
import { Link } from 'react-router-dom'
import { api } from '../api/client'
import type { Property, Meter, BillListItem } from '../types'
import { METER_TYPE_LABELS, METER_TYPE_COLORS, MONTHS } from '../types'

export default function Dashboard() {
  const [properties, setProperties] = useState<Property[]>([])
  const [activeId, setActiveId] = useState<number | null>(null)
  const [meters, setMeters] = useState<Meter[]>([])
  const [bills, setBills] = useState<BillListItem[]>([])
  const [loading, setLoading] = useState(true)
  const [alerts, setAlerts] = useState<any[]>([])

  useEffect(() => {
    api.listProperties().then((list) => {
      setProperties(list)
      if (list.length) setActiveId(list[0].id)
      else setLoading(false)
    }).catch(console.error)
  }, [])

  useEffect(() => {
    if (!activeId) return
    setLoading(true)
    Promise.all([
      api.listMeters(activeId),
      api.listBills(activeId, { limit: 5 }),
      api.notifications(activeId).catch(() => ({ items: [] })),
    ]).then(([m, b, n]) => {
      setMeters(m)
      setBills(b)
      setAlerts((n as any).items || [])
    }).finally(() => setLoading(false))
  }, [activeId])

  const active = properties.find((p) => p.id === activeId)

  return (
    <div className="dashboard">
      <div className="section-header">
        <h1>Главная</h1>
        {properties.length > 1 && (
          <select
            className="select-pill"
            value={activeId ?? ''}
            onChange={(e) => setActiveId(Number(e.target.value))}
          >
            {properties.map((p) => (
              <option key={p.id} value={p.id}>{p.name}</option>
            ))}
          </select>
        )}
      </div>

      {properties.length === 0 && (
        <div className="empty-state">
          <p>Пока нет объектов</p>
          <Link to="/more" className="btn primary">Добавить квартиру</Link>
        </div>
      )}

      {active && (
        <>
          <p className="property-label">{active.name}</p>
          <div className="quick-actions">
            <Link to="/readings" className="btn primary">+ Показания</Link>
            <Link to="/bills/new" className="btn secondary">+ Квитанция</Link>
          </div>

          {loading ? (
            <div className="skeleton-grid">
              <div className="skeleton" /><div className="skeleton" /><div className="skeleton" />
            </div>
          ) : (
            <>
              
          {alerts.length > 0 && (
            <div className="alerts-block">
              <h2 className="section-title">Уведомления</h2>
              {alerts.slice(0, 5).map((a, i) => (
                <div key={i} className={`alert-card alert-${a.severity}`}>
                  <div className="alert-title">{a.title}</div>
                  <div className="muted">{a.body}</div>
                </div>
              ))}
            </div>
          )}

              <h2 className="section-title">Счётчики</h2>
              <div className="card-grid">
                {meters.map((m) => (
                  <div key={m.id} className="resource-card" style={{ borderLeftColor: METER_TYPE_COLORS[m.type] }}>
                    <div className="resource-type">{METER_TYPE_LABELS[m.type]}</div>
                    <div className="resource-name">{m.name}</div>
                    {m.last_reading ? (
                      <>
                        <div className="resource-value">
                          {m.last_reading.value_t1}
                          {m.last_reading.value_t2 != null && (
                            <span className="muted"> / {m.last_reading.value_t2}</span>
                          )}
                          <span className="unit"> {m.unit}</span>
                        </div>
                        {m.last_reading.consumption_t1 != null && (
                          <div className="resource-cons">
                            расход {m.last_reading.consumption_t1}
                            {m.last_reading.consumption_t2 != null && ` + ${m.last_reading.consumption_t2}`}
                          </div>
                        )}
                      </>
                    ) : (
                      <div className="muted">Нет показаний</div>
                    )}
                  </div>
                ))}
                {meters.length === 0 && <p className="muted">Счётчики ещё не добавлены</p>}
              </div>

              <h2 className="section-title">Последние квитанции</h2>
              <div className="bill-list">
                {bills.map((b) => (
                  <Link key={b.id} to={`/bills/${b.id}`} className="bill-row">
                    <div>
                      <div className="bill-provider">{b.provider}</div>
                      <div className="muted">{MONTHS[b.period_month]} {b.period_year}</div>
                    </div>
                    <div className="bill-right">
                      <div className="bill-amount">{b.total_accrued.toLocaleString('ru-RU')} ₽</div>
                      <span className={`status-badge status-${b.status}`}>{b.status}</span>
                    </div>
                  </Link>
                ))}
                {bills.length === 0 && <p className="muted">Квитанций пока нет</p>}
              </div>
            </>
          )}
        </>
      )}
    </div>
  )
}
