import { useEffect, useState, useCallback } from 'react'
import { useParams, Link } from 'react-router-dom'
import { api } from '../api/client'
import type { Bill } from '../types'
import { MONTHS } from '../types'

export default function BillDetail() {
  const { id } = useParams()
  const [bill, setBill] = useState<Bill | null>(null)
  const [recognizing, setRecognizing] = useState(false)
  const [ocrMsg, setOcrMsg] = useState('')

  const load = useCallback(() => {
    if (id) api.getBill(Number(id)).then(setBill).catch(console.error)
  }, [id])

  useEffect(() => { load() }, [load])

  if (!bill) return <div className="muted">Загрузка…</div>

  const runOcr = async () => {
    setRecognizing(true)
    setOcrMsg('')
    try {
      const token = localStorage.getItem('token')
      const r = await fetch(`/api/v1/bills/${bill.id}/recognize?apply=true`, {
        method: 'POST',
        headers: { Authorization: `Bearer ${token}` },
      })
      const data = await r.json()
      setOcrMsg(data.message || data.status)
      load()
    } catch {
      setOcrMsg('Ошибка распознавания')
    } finally {
      setRecognizing(false)
    }
  }

  return (
    <div>
      <Link to="/bills" className="back-link">← Квитанции</Link>
      <div className="section-header">
        <h1>{bill.provider}</h1>
        <span className={`status-badge status-${bill.status}`}>{bill.status}</span>
      </div>
      <p className="muted">{MONTHS[bill.period_month]} {bill.period_year}</p>

      <div className="stat-row">
        <div className="stat-card">
          <div className="stat-label">Начислено</div>
          <div className="stat-value">{bill.total_accrued.toLocaleString('ru-RU')} ₽</div>
        </div>
        <div className="stat-card">
          <div className="stat-label">Оплачено</div>
          <div className="stat-value">{bill.total_paid.toLocaleString('ru-RU')} ₽</div>
        </div>
      </div>

      <h2 className="section-title">Услуги</h2>
      <div className="item-list">
        {bill.items.map((it) => (
          <div key={it.id} className="item-row">
            <span>{it.service_type?.name || it.raw_name || '—'}</span>
            <span className="item-amount">{it.amount.toLocaleString('ru-RU')} ₽</span>
          </div>
        ))}
        {bill.items.length === 0 && <p className="muted">Нет строк</p>}
      </div>

      {bill.payments.length > 0 && (
        <>
          <h2 className="section-title">Оплаты</h2>
          {bill.payments.map((p) => (
            <div key={p.id} className="item-row">
              <span>{p.payment_date} {p.method && `· ${p.method}`}</span>
              <span>{p.amount.toLocaleString('ru-RU')} ₽</span>
            </div>
          ))}
        </>
      )}

      {bill.file_path && (
        <>
          <button className="btn primary mt" disabled={recognizing} onClick={runOcr}>
            {recognizing ? 'Распознавание…' : 'Распознать файл (OCR)'}
          </button>
          {ocrMsg && <p className="muted mt">{ocrMsg}</p>}
          <a className="btn secondary mt" href={`/uploads/${bill.file_path}`} target="_blank" rel="noreferrer" style={{ display: 'inline-flex', marginLeft: 8 }}>
            Открыть файл ({bill.file_type})
          </a>
        </>
      )}
    </div>
  )
}
