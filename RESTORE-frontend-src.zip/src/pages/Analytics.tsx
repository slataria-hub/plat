import { useEffect, useState } from 'react'
import { api } from '../api/client'
import type { Property } from '../types'
import { MONTHS, METER_TYPE_COLORS } from '../types'

interface ConsRow {
  year: number; month: number; type: string; type_label: string
  consumption_t1: number; consumption_t2: number | null; unit: string
}
interface SpendRow {
  year: number; month: number; total: number
  water: number; heat: number; electricity: number; other: number
}
interface Summary {
  year: number; total_spent: number; months_with_bills: number
  consumption: Record<string, number>; avg_monthly_bill: number
}

export default function Analytics() {
  const [properties, setProperties] = useState<Property[]>([])
  const [propertyId, setPropertyId] = useState<number | null>(null)
  const [year, setYear] = useState(2025)
  const [cons, setCons] = useState<ConsRow[]>([])
  const [spend, setSpend] = useState<SpendRow[]>([])
  const [sum, setSum] = useState<Summary | null>(null)
  const [loading, setLoading] = useState(true)

  useEffect(() => {
    api.listProperties().then((p) => {
      setProperties(p)
      if (p.length) setPropertyId(p[0].id)
    })
  }, [])

  useEffect(() => {
    if (!propertyId) return
    setLoading(true)
    Promise.all([
      api.consumption(propertyId, year),
      api.spending(propertyId, year),
      api.summary(propertyId, year),
    ]).then(([c, s, sm]) => {
      setCons(c as ConsRow[])
      setSpend(s as SpendRow[])
      setSum(sm as Summary)
    }).catch(console.error).finally(() => setLoading(false))
  }, [propertyId, year])

  const maxSpend = Math.max(...spend.map((s) => s.total), 1)

  return (
    <div>
      <div className="section-header">
        <h1>Аналитика</h1>
        <select className="select-pill" value={year} onChange={(e) => setYear(Number(e.target.value))}>
          {[2026, 2025, 2024].map((y) => <option key={y} value={y}>{y}</option>)}
        </select>
      </div>

      {properties.length > 1 && (
        <select className="select-pill mb" value={propertyId ?? ''} onChange={(e) => setPropertyId(Number(e.target.value))}>
          {properties.map((p) => <option key={p.id} value={p.id}>{p.name}</option>)}
        </select>
      )}

      {loading ? <div className="skeleton" /> : (
        <>
          {sum && (
            <div className="stat-row">
              <div className="stat-card">
                <div className="stat-label">Потрачено за год</div>
                <div className="stat-value">{sum.total_spent.toLocaleString('ru-RU')} ₽</div>
              </div>
              <div className="stat-card">
                <div className="stat-label">Средний чек</div>
                <div className="stat-value">{sum.avg_monthly_bill.toLocaleString('ru-RU')} ₽</div>
              </div>
            </div>
          )}

          <h2 className="section-title">Траты по месяцам</h2>
          {spend.length === 0 && <p className="muted">Нет данных по квитанциям</p>}
          <div className="bar-chart">
            {spend.map((s) => (
              <div key={`${s.year}-${s.month}`} className="bar-row">
                <div className="bar-label">{MONTHS[s.month].slice(0, 3)}</div>
                <div className="bar-track">
                  <div className="bar-fill" style={{ width: `${(s.total / maxSpend) * 100}%` }} />
                </div>
                <div className="bar-value">{s.total.toLocaleString('ru-RU')}</div>
              </div>
            ))}
          </div>

          <h2 className="section-title">Расход ресурсов</h2>
          {cons.length === 0 && <p className="muted">Нет данных по показаниям</p>}
          <div className="cons-list">
            {cons.map((c, i) => (
              <div key={i} className="cons-row">
                <span className="dot" style={{ background: METER_TYPE_COLORS[c.type] || '#999' }} />
                <span>{MONTHS[c.month]} · {c.type_label}</span>
                <span className="cons-val">
                  {c.consumption_t1}{c.consumption_t2 != null ? ` + ${c.consumption_t2}` : ''} {c.unit}
                </span>
              </div>
            ))}
          </div>
        </>
      )}
    </div>
  )
}
