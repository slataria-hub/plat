const API = '/api/v1'

function getToken(): string | null {
  return localStorage.getItem('token')
}

export function setToken(token: string | null) {
  if (token) localStorage.setItem('token', token)
  else localStorage.removeItem('token')
}

function formatError(err: unknown, fallback: string): string {
  if (typeof err === 'string') return err
  if (Array.isArray(err)) {
    return err.map((e: any) => e.msg || JSON.stringify(e)).join('; ')
  }
  if (err && typeof err === 'object' && 'msg' in (err as any)) {
    return String((err as any).msg)
  }
  return fallback
}

async function request<T>(path: string, options: RequestInit = {}): Promise<T> {
  const headers: Record<string, string> = {
    ...(options.headers as Record<string, string> || {}),
  }
  const token = getToken()
  if (token) headers['Authorization'] = `Bearer ${token}`
  if (options.body && !(options.body instanceof FormData)) {
    headers['Content-Type'] = 'application/json'
  }

  const res = await fetch(`${API}${path}`, { ...options, headers })
  if (res.status === 401) {
    setToken(null)
    if (!window.location.pathname.includes('/login')) {
      window.location.href = '/login'
    }
    throw new Error('Unauthorized')
  }
  if (!res.ok) {
    const body = await res.json().catch(() => ({ detail: res.statusText }))
    throw new Error(formatError(body.detail, 'Ошибка запроса'))
  }
  if (res.status === 204) return undefined as T
  return res.json()
}

export const api = {
  register: (email: string, password: string, name?: string) =>
    request('/auth/register', { method: 'POST', body: JSON.stringify({ email, password, name }) }),
  login: async (email: string, password: string) => {
    const form = new URLSearchParams()
    form.set('username', email)
    form.set('password', password)
    const data = await request<{ access_token: string }>('/auth/login', {
      method: 'POST',
      headers: { 'Content-Type': 'application/x-www-form-urlencoded' },
      body: form,
    })
    setToken(data.access_token)
    return data
  },
  me: () => request<import('../types').User>('/auth/me'),

  listProperties: () => request<import('../types').Property[]>('/properties'),
  createProperty: (data: { name: string; address?: string; account_number?: string }) =>
    request<import('../types').Property>('/properties', { method: 'POST', body: JSON.stringify(data) }),

  listMeters: (propertyId: number) =>
    request<import('../types').Meter[]>(`/properties/${propertyId}/meters`),
  createMeter: (propertyId: number, data: object) =>
    request(`/properties/${propertyId}/meters`, { method: 'POST', body: JSON.stringify(data) }),
  listReadings: (meterId: number, year?: number) =>
    request<import('../types').MeterReading[]>(
      `/meters/${meterId}/readings${year ? `?year=${year}` : ''}`
    ),
  createReading: (meterId: number, data: object) =>
    request(`/meters/${meterId}/readings`, { method: 'POST', body: JSON.stringify(data) }),

  listBills: (propertyId: number, params?: Record<string, string | number>) => {
    const q = params ? '?' + new URLSearchParams(params as any).toString() : ''
    return request<import('../types').BillListItem[]>(`/properties/${propertyId}/bills${q}`)
  },
  getBill: (id: number) => request<import('../types').Bill>(`/bills/${id}`),
  createBill: (propertyId: number, data: object) =>
    request(`/properties/${propertyId}/bills`, { method: 'POST', body: JSON.stringify(data) }),

  listTariffs: (propertyId: number) => request(`/properties/${propertyId}/tariffs`),
  tariffChanges: (propertyId: number, from: string, to: string) =>
    request(`/properties/${propertyId}/tariffs/changes?from_date=${from}&to_date=${to}`),
  compareBills: (propertyId: number, prevY: number, prevM: number, currY: number, currM: number) =>
    request(`/properties/${propertyId}/bills/compare?prev_year=${prevY}&prev_month=${prevM}&curr_year=${currY}&curr_month=${currM}`),

  consumption: (propertyId: number, year?: number) =>
    request(`/properties/${propertyId}/analytics/consumption${year ? `?year=${year}` : ''}`),
  spending: (propertyId: number, year?: number) =>
    request(`/properties/${propertyId}/analytics/spending${year ? `?year=${year}` : ''}`),
  summary: (propertyId: number, year: number) =>
    request(`/properties/${propertyId}/analytics/summary?year=${year}`),
  exportExcelUrl: (propertyId: number) => `/api/v1/properties/${propertyId}/export/excel`,
  recognizeBill: (billId: number) => request(`/bills/${billId}/recognize`, { method: 'POST' }),
  backupZipUrl: () => '/api/v1/backup/zip',
  notifications: (propertyId?: number) =>
    request(`/notifications${propertyId ? `?property_id=${propertyId}` : ''}`),
}
