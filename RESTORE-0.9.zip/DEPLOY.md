# Деплой MeterApp (бесплатные варианты)

## Архитектура

- **Backend**: FastAPI → Render / Railway (free tier)
- **Frontend**: Vite React → Vercel / Netlify (free)
- **БД**: SQLite на диске сервиса (для старта) или Neon Postgres (бесплатно)

---

## 1. Backend на Render

1. Зарегистрируйтесь на https://render.com
2. **New → Web Service**
3. Подключите репозиторий с папкой `backend` или укажите Docker:
   - Dockerfile уже есть в корне `meter-app`
4. Настройки:
   - **Build**: `pip install -r requirements.txt`
   - **Start**: `uvicorn app.main:app --host 0.0.0.0 --port $PORT`
   - **Root Directory**: `backend` (если репозиторий = весь meter-app)
5. Environment:
   - `SECRET_KEY` = длинная случайная строка
   - `PYTHONPATH` = `.`
6. После деплоя API будет вида: `https://meterapp-xxx.onrender.com`

Проверка: `https://ВАШ-URL/docs`

---

## 2. Frontend на Vercel

1. https://vercel.com → New Project
2. Root Directory: `frontend`
3. Build: `npm run build`, Output: `dist`
4. Environment variable:
   - если API на другом домене — в `vite.config` или через proxy rewrite

### Proxy на Vercel (vercel.json в frontend)

```json
{
  "rewrites": [
    { "source": "/api/:path*", "destination": "https://ВАШ-BACKEND.onrender.com/api/:path*" },
    { "source": "/uploads/:path*", "destination": "https://ВАШ-BACKEND.onrender.com/uploads/:path*" },
    { "source": "/(.*)", "destination": "/index.html" }
  ]
}
```

---

## 3. Локально (напоминание Windows)

**Backend (PowerShell):**
```powershell
cd C:\Projects\PLAT\meter-app\backend
.\venv\Scripts\activate
$env:PYTHONPATH = "."
uvicorn app.main:app --reload --host 0.0.0.0 --port 8000
```

**Frontend:**
```powershell
cd C:\Projects\PLAT\meter-app\frontend
npm run dev
```

Сайт: http://localhost:5173  
API docs: http://127.0.0.1:8000/docs

---

## 4. Docker (опционально)

```bash
cd meter-app
docker compose up --build
```

---

## Важно для free-тарифов

- Render «засыпает» без запросов ~15 мин — первый запрос может быть долгим
- SQLite на ephemeral-диске Render может сбрасываться при redeploy — для надёжности позже подключите Neon Postgres
- Делайте ZIP-бэкап из приложения регулярно
