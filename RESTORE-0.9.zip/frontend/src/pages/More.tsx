import { useEffect, useState } from 'react'
import { useAuth } from '../hooks/useAuth'
import { api } from '../api/client'
import type { Property } from '../types'

export default function More() {
  const { user, logout } = useAuth()
  const [properties, setProperties] = useState<Property[]>([])
  const [showForm, setShowForm] = useState(false)
  const [name, setName] = useState('')
  const [address, setAddress] = useState('')
  const [account, setAccount] = useState('')
  const [exporting, setExporting] = useState<number | null>(null)
  const [backingUp, setBackingUp] = useState(false)
  const [importing, setImporting] = useState<number | null>(null)
  const [importMsg, setImportMsg] = useState('')

  const load = () => api.listProperties().then(setProperties)
  useEffect(() => { load() }, [])

  const create = async (e: React.FormEvent) => {
    e.preventDefault()
    await api.createProperty({ name, address: address || undefined, account_number: account || undefined })
    setShowForm(false)
    setName(''); setAddress(''); setAccount('')
    load()
  }

  const downloadExcel = async (p: Property) => {
    setExporting(p.id)
    try {
      const token = localStorage.getItem('token')
      const res = await fetch(api.exportExcelUrl(p.id), {
        headers: { Authorization: `Bearer ${token}` },
      })
      if (!res.ok) throw new Error('Ошибка экспорта')
      const blob = await res.blob()
      const url = URL.createObjectURL(blob)
      const a = document.createElement('a')
      a.href = url
      a.download = `meterapp_${p.name.replace(/\s+/g, '_')}.xlsx`
      a.click()
      URL.revokeObjectURL(url)
    } catch {
      alert('Не удалось скачать файл')
    } finally {
      setExporting(null)
    }
  }

  const downloadBackup = async () => {
    setBackingUp(true)
    try {
      const token = localStorage.getItem('token')
      const res = await fetch(api.backupZipUrl(), {
        headers: { Authorization: `Bearer ${token}` },
      })
      if (!res.ok) throw new Error('Ошибка')
      const blob = await res.blob()
      const url = URL.createObjectURL(blob)
      const a = document.createElement('a')
      a.href = url
      a.download = `meterapp_backup.zip`
      a.click()
      URL.revokeObjectURL(url)
    } catch {
      alert('Не удалось скачать бэкап')
    } finally {
      setBackingUp(false)
    }
  }

  const onImport = async (p: Property, file: File) => {
    setImporting(p.id)
    setImportMsg('')
    try {
      const report = await api.importExcel(p.id, file)
      const s = report.summary || {}
      setImportMsg(
        `Импорт «${p.name}»: показаний +${s.readings_created || 0}, квитанций +${s.bills_created || 0}`
      )
    } catch (e: any) {
      setImportMsg(e.message || 'Ошибка импорта')
    } finally {
      setImporting(null)
    }
  }

  return (
    <div>
      <h1 className="page-title">Ещё</h1>
      <p className="muted">{user?.email}</p>

      <h2 className="section-title">Квартиры / объекты</h2>
      {properties.map((p) => (
        <div key={p.id} className="card property-card">
          <div className="card-title">{p.name}</div>
          {p.address && <div className="muted">{p.address}</div>}
          {p.account_number && <div className="muted">Л/С: {p.account_number}</div>}
          <div className="btn-row">
            <button className="btn secondary small" disabled={exporting === p.id} onClick={() => downloadExcel(p)}>
              {exporting === p.id ? '…' : 'Excel ↓'}
            </button>
            <label className="btn secondary small" style={{ cursor: 'pointer' }}>
              {importing === p.id ? 'Импорт…' : 'Импорт Excel ↑'}
              <input
                type="file"
                accept=".xlsx,.xlsm"
                hidden
                disabled={importing === p.id}
                onChange={(e) => {
                  const f = e.target.files?.[0]
                  if (f) onImport(p, f)
                  e.target.value = ''
                }}
              />
            </label>
          </div>
        </div>
      ))}

      {importMsg && <div className="info-box mt">{importMsg}</div>}

      {!showForm ? (
        <button className="btn primary mt" onClick={() => setShowForm(true)}>+ Квартира</button>
      ) : (
        <form className="card form-card mt" onSubmit={create}>
          <label>Название<input value={name} onChange={(e) => setName(e.target.value)} required /></label>
          <label>Адрес<input value={address} onChange={(e) => setAddress(e.target.value)} /></label>
          <label>Лицевой счёт<input value={account} onChange={(e) => setAccount(e.target.value)} /></label>
          <div className="btn-row">
            <button type="submit" className="btn primary">Сохранить</button>
            <button type="button" className="btn secondary" onClick={() => setShowForm(false)}>Отмена</button>
          </div>
        </form>
      )}

      <h2 className="section-title">Данные</h2>
      <button className="btn secondary" disabled={backingUp} onClick={downloadBackup}>
        {backingUp ? 'Подготовка…' : 'Полный бэкап (ZIP)'}
      </button>
      <p className="muted small mt">
        Импорт Excel поддерживает листы с показаниями воды/электричества и оплатами
        (формат «Показания счётчиков / оплата ЖКХ»). Повторный импорт не дублирует те же даты.
      </p>

      <h2 className="section-title">Подсказки</h2>
      <ul className="tips-list">
        <li>Сначала добавьте квартиру, затем счётчики на экране «Показания».</li>
        <li>Квитанцию можно загрузить PDF/фото и нажать «Распознать».</li>
        <li>Импорт Excel удобен для переноса старой истории.</li>
        <li>Бэкап ZIP сохраняет данные и файлы — храните копию отдельно.</li>
      </ul>

      <button className="btn danger mt" onClick={logout}>Выйти</button>
    </div>
  )
}
