from contextlib import asynccontextmanager
from fastapi import FastAPI
from fastapi.middleware.cors import CORSMiddleware
from fastapi.staticfiles import StaticFiles
from pathlib import Path
from app.core.config import settings
from app.core.database import init_db, SessionLocal
from app.api import auth, properties, meters, bills, tariffs, export_analytics, notifications
from app.services.seed import seed_service_types
from app.services.files import ensure_upload_dir


@asynccontextmanager
async def lifespan(app: FastAPI):
    init_db()
    ensure_upload_dir()
    db = SessionLocal()
    try:
        count = seed_service_types(db)
        db.commit()
        if count:
            print(f"Seeded {count} service types")
    finally:
        db.close()
    yield


app = FastAPI(
    title=settings.PROJECT_NAME,
    version=settings.VERSION,
    lifespan=lifespan,
)

app.add_middleware(
    CORSMiddleware,
    allow_origins=["*"],
    allow_credentials=True,
    allow_methods=["*"],
    allow_headers=["*"],
)

app.include_router(auth.router, prefix=settings.API_V1_PREFIX)
app.include_router(properties.router, prefix=settings.API_V1_PREFIX)
app.include_router(meters.router, prefix=settings.API_V1_PREFIX)
app.include_router(bills.router, prefix=settings.API_V1_PREFIX)
app.include_router(tariffs.router, prefix=settings.API_V1_PREFIX)
app.include_router(export_analytics.router, prefix=settings.API_V1_PREFIX)
app.include_router(notifications.router, prefix=settings.API_V1_PREFIX)

upload_path = Path(settings.UPLOAD_DIR)
upload_path.mkdir(parents=True, exist_ok=True)
app.mount("/uploads", StaticFiles(directory=str(upload_path)), name="uploads")


@app.get("/")
def root():
    return {
        "name": settings.PROJECT_NAME,
        "version": settings.VERSION,
        "status": "ok",
    }


@app.get("/health")
def health():
    return {"status": "healthy"}
